/**
 * Client research chrome — preserves existing Momentum UI.
 * Adds freshness banner + tabbed research drawer (Setups / BTC filters / Traction / Holdings).
 */
(function () {
  const MAIN = { freshMs: 45 * 60 * 1000, staleMs: 3 * 60 * 60 * 1000 };
  const HF = { freshMs: 60 * 1000, staleMs: 5 * 60 * 1000 };
  const FUTURE_SKEW = 5 * 60 * 1000;
  const WATCH_KEY = "cmr:my-holdings:v1";
  const DEFAULT_WATCH = ["XRP", "AERO", "UNI", "DOGE", "HBAR", "ARB", "SOL", "ETH"];
  const TAB_KEY = "cmr:research-tab:v2";
  const OPEN_KEY = "cmr:research-open:v2";

  let lastMain = null;
  let lastHf = null;
  let activeTab = "whales";
  let researchOpen = false;
  let panelsLoaded = false;
  let researchRefreshTimer = null;
  let fomoAlertTimer = null;
  let lastFomoAlertIds = {};
  const RESEARCH_REFRESH_MS = 2 * 60 * 1000;
  const FOMO_ALERT_POLL_MS = 30 * 1000;
  const FOMO_SEEN_KEY = "cmr:fomo-alert-seen-ids:v1";

  function parseTs(v) {
    if (v == null || v === "") return null;
    const ms = typeof v === "number" ? (v < 1e12 ? v * 1000 : v) : Date.parse(v);
    return Number.isFinite(ms) ? ms : null;
  }

  function compute(sourceGeneratedAt, cadence) {
    const now = Date.now();
    const ms = parseTs(sourceGeneratedAt);
    if (ms == null) {
      return { status: "unknown", ageHours: null, ageMinutes: null, ageSeconds: null, sourceGeneratedAt: null, actionable: false };
    }
    if (ms - now > FUTURE_SKEW) {
      return { status: "unknown", ageHours: null, ageMinutes: null, ageSeconds: null, sourceGeneratedAt: new Date(ms).toISOString(), actionable: false, reason: "materially_future_dated" };
    }
    const ageMs = Math.max(0, now - ms);
    let status = "expired";
    if (ageMs < cadence.freshMs) status = "fresh";
    else if (ageMs < cadence.staleMs) status = "stale";
    return {
      status,
      ageMs,
      ageHours: Math.round((ageMs / 3600000) * 10) / 10,
      ageMinutes: Math.round((ageMs / 60000) * 10) / 10,
      ageSeconds: Math.round(ageMs / 1000),
      sourceGeneratedAt: new Date(ms).toISOString(),
      evaluatedAt: new Date(now).toISOString(),
      actionable: status === "fresh",
    };
  }

  function loadWatch() {
    try {
      const raw = localStorage.getItem(WATCH_KEY);
      if (!raw) return DEFAULT_WATCH.slice();
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length) return parsed.map(function (s) { return String(s).toUpperCase(); });
    } catch (_) {}
    return DEFAULT_WATCH.slice();
  }

  function saveWatch(list) {
    localStorage.setItem(WATCH_KEY, JSON.stringify(list));
  }

  function ensureStyles() {
    if (document.getElementById("cmr-freshness-styles")) return;
    const style = document.createElement("style");
    style.id = "cmr-freshness-styles";
    style.textContent = [
      "#cmr-freshness-banner{position:sticky;top:0;z-index:9999;padding:10px 16px;font:600 13px/1.4 'IBM Plex Mono',ui-monospace,monospace;letter-spacing:.02em;border-bottom:1px solid rgba(255,255,255,.08)}",
      "#cmr-freshness-banner[data-status=fresh]{background:#0d2818;color:#9dffb9}",
      "#cmr-freshness-banner[data-status=stale]{background:#3a2a0a;color:#ffd27a}",
      "#cmr-freshness-banner[data-status=expired],#cmr-freshness-banner[data-status=unknown]{background:#3a1010;color:#ffb4b4}",
      "#cmr-freshness-banner small{opacity:.8;font-weight:400;display:block;margin-top:2px}",
      "#cmr-research-toggle{position:fixed;right:12px;bottom:12px;z-index:9998;font:600 12px/1 'IBM Plex Mono',ui-monospace,monospace;letter-spacing:.04em;background:#0f1624;color:#e8eef8;border:1px solid rgba(255,255,255,.18);border-radius:6px;padding:10px 14px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.4)}",
      "#cmr-research-toggle:hover{border-color:rgba(255,255,255,.35);background:#152036}",
      "#cmr-research-toggle[hidden]{display:none!important}",
      "#cmr-research{position:fixed;right:12px;bottom:12px;z-index:9998;width:min(440px,calc(100vw - 24px));max-height:min(78vh,640px);overflow:auto;background:rgba(6,9,15,.96);color:#d7dde8;border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:12px 14px;font:12px/1.45 'IBM Plex Mono',ui-monospace,monospace;box-shadow:0 12px 40px rgba(0,0,0,.45)}",
      "#cmr-research[data-open=false]{display:none}",
      "#cmr-research[data-open=true]{display:block}",
      "#cmr-research .cmr-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0 0 8px}",
      "#cmr-research h3{margin:0;font-size:13px;font-weight:600;color:#fff}",
      "#cmr-research .cmr-close{font:inherit;background:transparent;color:#c9d2e0;border:1px solid rgba(255,255,255,.14);border-radius:4px;padding:4px 8px;cursor:pointer}",
      "#cmr-research .tabs{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}",
      "#cmr-research .tabs button{font:inherit;background:#121826;color:#c9d2e0;border:1px solid rgba(255,255,255,.12);border-radius:4px;padding:6px 8px;cursor:pointer}",
      "#cmr-research .tabs button[aria-selected=true]{background:#1c2a44;color:#fff;border-color:rgba(255,255,255,.28)}",
      "#cmr-research .cmr-row{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-top:1px solid rgba(255,255,255,.06)}",
      "#cmr-research button,#cmr-research input, #cmr-research select{font:inherit;background:#121826;color:#fff;border:1px solid rgba(255,255,255,.14);border-radius:4px;padding:6px 8px}",
      "#cmr-research .muted{opacity:.7}",
      "#cmr-research .warn{color:#ffd27a}",
      "#cmr-research .ok{color:#9dffb9}",
      "#cmr-research .panel{display:none}",
      "#cmr-research .panel.active{display:block}",
      "#cmr-fomo-alert-banner{position:sticky;top:44px;z-index:9998;padding:10px 16px;font:600 12px/1.4 'IBM Plex Mono',ui-monospace,monospace;background:#1a1408;color:#ffd27a;border-bottom:1px solid rgba(255,210,122,.25);display:none}",
      "#cmr-fomo-alert-banner[data-show=true]{display:block}",
      "#cmr-enable-alerts{position:fixed;right:16px;bottom:64px;z-index:10001;font:600 12px/1 'IBM Plex Mono',ui-monospace,monospace;background:#1c2a44;color:#fff;border:1px solid rgba(255,255,255,.28);border-radius:4px;padding:10px 12px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.35)}",
      "#cmr-enable-alerts[data-on=true]{background:#143322;border-color:rgba(157,255,185,.35);color:#9dffb9}",
      "@media (max-width:640px){#cmr-research,#cmr-research-toggle{right:8px;left:8px;width:auto;bottom:8px}#cmr-research-toggle{left:auto}#cmr-enable-alerts{right:8px;bottom:56px}}",
    ].join("");
    document.head.appendChild(style);
  }

  function ensureBanner() {
    ensureStyles();
    let el = document.getElementById("cmr-freshness-banner");
    if (!el) {
      el = document.createElement("div");
      el.id = "cmr-freshness-banner";
      el.setAttribute("role", "status");
      document.body.insertBefore(el, document.body.firstChild);
    }
    return el;
  }

  function renderBanner() {
    const el = ensureBanner();
    const main = lastMain && lastMain.data && lastMain.data.freshness;
    const hf = lastHf && lastHf.data && lastHf.data.freshness;
    if (!main) {
      el.dataset.status = "unknown";
      el.innerHTML = "Momentum freshness unknown<small>Waiting for /api/momentum</small>";
      return;
    }
    const f = compute(main.sourceGeneratedAt || (lastMain.data && lastMain.data.sourceGeneratedAt), MAIN);
    el.dataset.status = f.status;
    const actionable = f.actionable ? "research context only — not trade advice" : "NOT current actionable signals — historical reference";
    const refresh = lastMain.refresh;
    const refreshLine = refresh
      ? "attempt " + (refresh.lastAttemptAt || "—") + " · success " + (refresh.lastSuccessAt || "—") + (refresh.lastError ? " · err " + refresh.lastError : "")
      : "refresh status unavailable";
    const hfLine = hf ? "HF: " + hf.status + " · " + (hf.ageSeconds != null ? hf.ageSeconds + "s" : "—") : "HF: —";
    el.innerHTML =
      "Momentum: <strong>" + f.status.toUpperCase() + "</strong> · age " +
      (f.ageHours != null ? f.ageHours + "h" : "—") +
      " · src " + (f.sourceGeneratedAt || "—") +
      "<small>" + actionable + " · " + refreshLine + " · " + hfLine + "</small>";
  }

  function ensureFomoAlertBanner() {
    ensureStyles();
    let el = document.getElementById("cmr-fomo-alert-banner");
    if (!el) {
      el = document.createElement("div");
      el.id = "cmr-fomo-alert-banner";
      el.setAttribute("role", "status");
      el.dataset.show = "false";
      const main = document.getElementById("cmr-freshness-banner");
      if (main && main.parentNode) main.parentNode.insertBefore(el, main.nextSibling);
      else document.body.insertBefore(el, document.body.firstChild);
    }
    return el;
  }

  function loadSeenFomoIds() {
    try {
      const raw = localStorage.getItem(FOMO_SEEN_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch (_) {
      return {};
    }
  }

  function saveSeenFomoIds(map) {
    try { localStorage.setItem(FOMO_SEEN_KEY, JSON.stringify(map)); } catch (_) {}
  }

  function showBrowserFomoNotice(alert) {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    const clear = alert.risk && alert.risk.status === "clear" && !alert.risk.risky;
    try {
      new Notification((clear ? "FOMO CLEAR " : "FOMO ") + (alert.symbol || "alert"), {
        body: (alert.buyers || 0) + " trusted buyers · " +
          (clear ? "GoPlus clear · " : "") + "copying off",
        tag: alert.id || alert.tokenAddress,
      });
    } catch (_) {}
  }

  function paintFomoAlertBanner(alerts) {
    const el = ensureFomoAlertBanner();
    if (!alerts || !alerts.length) {
      el.dataset.show = "false";
      el.innerHTML = "";
      return;
    }
    const clearFirst = alerts.find(function (a) {
      return a.risk && a.risk.status === "clear" && !a.risk.risky;
    });
    const newest = clearFirst || alerts[0];
    const clear = newest.risk && newest.risk.status === "clear" && !newest.risk.risky;
    el.dataset.show = "true";
    el.innerHTML =
      (clear ? "FOMO CLEAR: " : "FOMO alert: ") +
      "<strong>" + esc(newest.symbol || "?") + "</strong> · " +
      (newest.buyers || 0) + " trusted" +
      "<small>Immediate cohort alert · copying off · not auto-trade · tap Research → Whales</small>";
  }

  async function pollFomoAlerts(opts) {
    const forcePass = opts && opts.forcePass;
    try {
      if (forcePass) {
        await origFetch("/api/fomo-alerts", { method: "POST" }).catch(function () {});
      }
      const res = await origFetch("/api/fomo-alerts");
      const json = await res.json();
      const alerts = (json.data && json.data.alerts) || [];
      const seen = loadSeenFomoIds();
      const fresh = [];
      alerts.forEach(function (a) {
        const id = a.id || a.tokenAddress;
        if (!id) return;
        if (!seen[id] && !lastFomoAlertIds[id]) fresh.push(a);
        lastFomoAlertIds[id] = true;
      });
      if (fresh.length) {
        fresh.forEach(function (a) {
          const id = a.id || a.tokenAddress;
          seen[id] = Date.now();
          showBrowserFomoNotice(a);
        });
        saveSeenFomoIds(seen);
        paintFomoAlertBanner(fresh);
        if (researchOpen && activeTab === "whales") {
          panelsLoaded = false;
          loadWhales();
        }
      } else if (alerts.length) {
        paintFomoAlertBanner(alerts.slice(0, 1));
      }
    } catch (_) {}
  }

  function startFomoAlertPoll() {
    if (fomoAlertTimer) return;
    pollFomoAlerts({ forcePass: true });
    fomoAlertTimer = setInterval(function () {
      if (document.hidden) return;
      pollFomoAlerts({ forcePass: true });
    }, FOMO_ALERT_POLL_MS);
  }

  function ensureToggle() {
    ensureStyles();
    let btn = document.getElementById("cmr-research-toggle");
    if (btn) return btn;
    btn = document.createElement("button");
    btn.id = "cmr-research-toggle";
    btn.type = "button";
    btn.textContent = "Research";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", "cmr-research");
    btn.addEventListener("click", function () {
      setResearchOpen(true);
    });
    document.body.appendChild(btn);
    return btn;
  }

  function setResearchOpen(open) {
    researchOpen = Boolean(open);
    try { localStorage.setItem(OPEN_KEY, researchOpen ? "1" : "0"); } catch (_) {}
    const el = ensureResearch();
    const toggle = ensureToggle();
    el.dataset.open = researchOpen ? "true" : "false";
    el.setAttribute("aria-hidden", researchOpen ? "false" : "true");
    toggle.hidden = researchOpen;
    toggle.setAttribute("aria-expanded", researchOpen ? "true" : "false");
    if (researchOpen) {
      syncTabs();
      loadActivePanel(true);
      startResearchRefresh();
    } else {
      stopResearchRefresh();
    }
  }

  function stopResearchRefresh() {
    if (researchRefreshTimer) {
      clearInterval(researchRefreshTimer);
      researchRefreshTimer = null;
    }
  }

  function startResearchRefresh() {
    stopResearchRefresh();
    researchRefreshTimer = setInterval(function () {
      if (!researchOpen) return;
      if (document.hidden) return;
      panelsLoaded = false;
      loadActivePanel(true);
    }, RESEARCH_REFRESH_MS);
  }

  function loadActivePanel(force) {
    if (!researchOpen) return;
    if (!force && panelsLoaded) return;
    panelsLoaded = true;
    if (activeTab === "whales") loadWhales();
    else if (activeTab === "setups") loadSetups();
    else if (activeTab === "btc") loadBtc();
    else if (activeTab === "traction") loadTraction();
    else if (activeTab === "holdings") renderWatch();
  }

  function watchlistQuery() {
    return loadWatch().map(function (s) { return encodeURIComponent(s); }).join(",");
  }

  function ensureResearch() {
    ensureStyles();
    let el = document.getElementById("cmr-research");
    if (el) return el;
    try { activeTab = localStorage.getItem(TAB_KEY) || "whales"; } catch (_) {}
    el = document.createElement("aside");
    el.id = "cmr-research";
    el.dataset.open = "false";
    el.setAttribute("aria-hidden", "true");
    el.setAttribute("aria-label", "Research drawer");
    el.innerHTML = [
      "<div class='cmr-head'><h3>Research</h3>",
      "<button type='button' class='cmr-close' id='cmr-research-close' aria-label='Close research'>Close</button></div>",
      "<div class='tabs' role='tablist'>",
      "<button type='button' data-tab='whales'>Whales</button>",
      "<button type='button' data-tab='setups'>Early Setups</button>",
      "<button type='button' data-tab='btc'>BTC-relative</button>",
      "<button type='button' data-tab='traction'>Traction</button>",
      "<button type='button' data-tab='holdings'>Holdings</button>",
      "</div>",
      "<div id='cmr-panel-whales' class='panel'><div class='muted'>Product radar: trusted FOMO wallets + large DEX buys. Risky coins labeled. Copying is off.</div><div id='cmr-whales'></div></div>",
      "<div id='cmr-panel-setups' class='panel'><div class='muted'>Pre-breakout only — not the momentum leaderboard. Confirmed and Overextended coins are excluded. Compression ≠ bullish.</div><div id='cmr-setups'></div></div>",
      "<div id='cmr-panel-btc' class='panel'><div class='muted'>Filters use excess pp & coin/BTC % — 90d never extrapolated</div>",
      "<select id='cmr-btc-filter'><option value=''>Ranked universe</option>",
      "<option value='beating-btc-7d'>Beating BTC (7d)</option>",
      "<option value='beating-btc-30d'>Beating BTC (30d)</option>",
      "<option value='beating-btc-all-available'>Beating BTC (all available)</option>",
      "<option value='improving-btc'>Improving vs BTC</option></select>",
      "<div id='cmr-btc-list' style='margin-top:8px'></div></div>",
      "<div id='cmr-panel-traction' class='panel'><div class='muted'>For Coiling/Igniting candidates — missing social = unknown</div>",
      "<div id='cmr-traction'></div></div>",
      "<div id='cmr-panel-holdings' class='panel'><div class='muted'>No size/PnL inferred</div>",
      "<div style='display:flex;gap:6px;margin:8px 0'><input id='cmr-watch-input' style='flex:1' placeholder='Add symbol' />",
      "<button type='button' id='cmr-watch-save'>Save</button></div>",
      "<div id='cmr-watch-list' class='muted'></div></div>",
      "<div style='margin-top:10px' class='muted'>High score ≠ favorable entry. Paper tracking only.</div>",
    ].join("");
    document.body.appendChild(el);

    el.querySelector("#cmr-research-close").addEventListener("click", function () {
      setResearchOpen(false);
    });
    el.querySelectorAll(".tabs button").forEach(function (btn) {
      btn.addEventListener("click", function () {
        activeTab = btn.getAttribute("data-tab");
        try { localStorage.setItem(TAB_KEY, activeTab); } catch (_) {}
        syncTabs();
        panelsLoaded = false;
        loadActivePanel(true);
      });
    });
    el.querySelector("#cmr-watch-save").addEventListener("click", function () {
      const input = el.querySelector("#cmr-watch-input");
      const cur = loadWatch();
      const add = String(input.value || "").toUpperCase().trim();
      if (add && cur.indexOf(add) < 0) cur.push(add);
      saveWatch(cur);
      input.value = "";
      renderWatch();
      panelsLoaded = false;
    });
    el.querySelector("#cmr-btc-filter").addEventListener("change", loadBtc);
    syncTabs();
    return el;
  }

  function syncTabs() {
    const el = ensureResearch();
    el.querySelectorAll(".tabs button").forEach(function (btn) {
      btn.setAttribute("aria-selected", btn.getAttribute("data-tab") === activeTab ? "true" : "false");
    });
    el.querySelectorAll(".panel").forEach(function (p) {
      p.classList.toggle("active", p.id === "cmr-panel-" + activeTab);
    });
  }

  function renderWatch() {
    ensureResearch().querySelector("#cmr-watch-list").textContent = loadWatch().join(" · ") || "(empty)";
  }


  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function fmtUsd(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return "—";
    if (n >= 1e6) return "$" + (Math.round(n / 1e5) / 10) + "M";
    if (n >= 1e3) return "$" + Math.round(n / 1e3) + "k";
    return "$" + Math.round(n);
  }

  function fmtPct(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return "—";
    return (Math.round(n * 10) / 10) + "%";
  }

  function setupRowHtml(s) {
    const snap = s.snapshot || {};
    const br = s.btcRelative && s.btcRelative.d7;
    const brLine = br && br.available ? " · " + br.excessReturnPp + "pp vs BTC" : "";
    const ohlcvNote = s.ohlcv && s.ohlcv.approximate ? " · CG approx OHLC" : "";
    const move = "24h " + fmtPct(snap.change24h) + " · 7d " + fmtPct(snap.change7d) +
      " · vol " + fmtPct(snap.volumeChange24h);
    const evidence = (s.evidence || []).filter(function (line) {
      return line && line.indexOf("Momentum score") !== 0;
    }).slice(0, 2);
    return (
      "<div class='cmr-row'><span><strong>" + (s.symbol || "?") + "</strong> " +
      (s.state || "n/a") +
      (snap.risk && snap.risk.risky ? " <span class='warn'>Risky coin</span>" : "") +
      "<div class='muted'>ready " + (s.setupReadiness != null ? s.setupReadiness : "—") +
      " · " + (s.dataConfidence || "") + " · " + move + brLine + ohlcvNote +
      "</div>" +
      (snap.risk && snap.risk.risky && snap.risk.label
        ? "<div class='warn'>" + snap.risk.label + "</div>"
        : "") +
      evidence.map(function (line) { return "<div class='muted'>" + line + "</div>"; }).join("") +
      (s.trigger ? "<div class='muted'>trigger: " + s.trigger + "</div>" : "") +
      "</span></div>"
    );
  }

  function whaleRowHtml(a) {
    const risk = a.risk || {};
    const risky = risk.risky ? " <span class='warn'>Risky coin</span>" : "";
    const sizeNote = a.usdReliable ? "" : " · USD print exceeds pool reserves";
    const repeat = a.repeatInWindow
      ? "<div class='muted'>" + (a.repeatCount || 2) + " buys from this wallet in the scan. Not a profit track record.</div>"
      : "";
    return (
      "<div class='cmr-row'><span><strong>" + esc(a.symbol || a.walletShort || "?") + "</strong> " +
      esc(a.chainLabel || a.chain || "") + risky +
      "<div class='muted'>" + esc(a.walletShort || "") + " bought " + fmtUsd(a.usd) + sizeNote +
      (a.pool ? " · " + esc(a.pool) : "") +
      (a.at ? " · " + esc(String(a.at).replace("T", " ").replace("Z", "Z")) : "") +
      "</div>" +
      (risk.label ? "<div class='warn'>" + esc(risk.label) + "</div>" : "") +
      repeat +
      (a.txUrl ? "<div class='muted'><a href='" + esc(a.txUrl) + "' target='_blank' rel='noopener'>tx</a> · copying off</div>" : "") +
      "</span></div>"
    );
  }

  function trustedRowHtml(a) {
    const risk = a.risk || {};
    const risky = risk.risky ? " <span class='warn'>Risky coin</span>" : "";
    const who = (a.who || []).slice(0, 4).join(", ");
    const more = a.whoTotal > 4 ? " +" + (a.whoTotal - 4) : "";
    return (
      "<div class='cmr-row'><span><strong>" + esc(a.symbol || "?") + "</strong> " +
      esc(a.chainLabel || "Robinhood") +
      (a.kind === "fresh" ? " <span class='ok'>Fresh</span>" : "") +
      risky +
      "<div class='muted'>" + (a.buyers || 0) + " trusted buyers · score " +
      (a.avgScore != null ? Math.round(a.avgScore) : "—") +
      " · " + fmtUsd(a.usd) +
      (a.liquidityUsd != null ? " · liq " + fmtUsd(a.liquidityUsd) : "") +
      "</div>" +
      (who ? "<div class='muted'>" + esc(who) + esc(more) + "</div>" : "") +
      (risk.label ? "<div class='warn'>" + esc(risk.label) + "</div>" : "") +
      "<div class='muted'>copying off · via FOMO Radar</div>" +
      "</span></div>"
    );
  }

  async function loadWhales() {
    const box = ensureResearch().querySelector("#cmr-whales");
    box.innerHTML = "<div class='muted'>Loading both radar feeds…</div>";
    try {
      const alertRes = await origFetch("/api/fomo-alerts");
      const alertJson = await alertRes.json();
      const immediate = (alertJson.data && alertJson.data.alerts) || [];
      const notify = (alertJson.data && alertJson.data.notify) || {};

      const res = await origFetch("/api/radar-product");
      const json = await res.json();
      const trusted = (json.data && json.data.trustedWallets) || [];
      const large = (json.data && json.data.largeBuys) || [];
      const product = (json.data && json.data.product) || {};
      let html = "<div class='muted'>" + esc(product.note || "Both feeds. Copying off.") + "</div>";

      html += "<div style='margin-top:10px'><strong>Immediate FOMO alerts</strong></div>";
      html += "<div class='muted'>Clear GoPlus coins alert now. Tap <strong>Enable alerts</strong> for phone push. Auto-trade is off." +
        (notify.any ? " Push channel ready." : " Server push arming…") +
        "</div>";
      if (!immediate.length) html += "<div class='muted'>No FOMO alerts yet — open this tab and wait for the 30s poller, or wait for cron.</div>";
      else html += immediate.slice(0, 8).map(trustedRowHtml).join("");

      html += "<div style='margin-top:12px'><strong>Trusted wallets</strong></div>";
      html += "<div class='muted'>FOMO Robinhood Radar — named traders, cohort score. Not a profit guarantee.</div>";
      if (!trusted.length) html += "<div class='muted'>No trusted-wallet signals right now.</div>";
      else html += trusted.map(trustedRowHtml).join("");

      html += "<div style='margin-top:12px'><strong>Large DEX buys</strong></div>";
      html += "<div class='muted'>GeckoTerminal — buys ≥ $10k on ETH / BSC / Base. No wallet PnL.</div>";
      if (!large.length) html += "<div class='muted'>No large buys in the scanned pools right now.</div>";
      else html += large.map(whaleRowHtml).join("");

      box.innerHTML = html;
    } catch (_) {
      box.innerHTML = "<div class='warn'>Radar product unavailable</div>";
    }
  }

  async function loadSetups() {
    const box = ensureResearch().querySelector("#cmr-setups");
    box.innerHTML = "<div class='muted'>Scanning pre-breakout coins…</div>";
    try {
      const res = await origFetch(
        "/api/early-setups?limit=8&offset=0&candles=1&timeframe=1h&excludeHoldings=1&early=1&prioritizeHoldings=0&universe=1&symbols=" +
          watchlistQuery()
      );
      const json = await res.json();
      const freshness = json.data && json.data.freshness;
      const meta = json.metadata || {};
      const setups = ((json.data && json.data.setups) || []).filter(function (s) {
        return s.state === "Coiling" || s.state === "Igniting";
      });
      const universe = (json.data && json.data.universe) || [];
      const scanned = new Set(setups.map(function (s) { return String(s.symbol || "").toUpperCase(); }));
      let html = "";
      if (freshness && freshness.status !== "fresh") {
        html += "<div class='warn'>Gated: momentum data is " + freshness.status + "</div>";
      }
      html += "<div class='muted'>Pre-breakout pool " + (meta.universeTotal != null ? meta.universeTotal : universe.length) +
        " (Building/Watch, not already extended). Candle setups " + setups.length + ".</div>";
      if (!setups.length) {
        html += "<div class='muted'>No Coiling/Igniting in the candle slice yet.</div>";
      }
      html += setups.map(setupRowHtml).join("");
      const rest = universe.filter(function (u) { return !scanned.has(String(u.symbol || "").toUpperCase()); });
      if (rest.length) {
        html += "<div class='muted' style='margin-top:8px'>Still coiling on the snapshot — not the leaderboard</div>";
        html += rest.map(function (u) {
          return "<div class='cmr-row'><span><strong>" + (u.symbol || "?") + "</strong> " +
            (u.momentumState || "") +
            "<div class='muted'>24h " + fmtPct(u.change24h) + " · 7d " + fmtPct(u.change7d) +
            " · vol " + fmtPct(u.volumeChange24h) + "</div></span></div>";
        }).join("");
      }
      box.innerHTML = html;
    } catch (_) {
      box.innerHTML = "<div class='warn'>Early setups unavailable</div>";
    }
  }

  async function loadBtc() {
    const box = ensureResearch().querySelector("#cmr-btc-list");
    const filter = ensureResearch().querySelector("#cmr-btc-filter").value;
    box.innerHTML = "<div class='muted'>Loading…</div>";
    try {
      const res = await origFetch("/api/momentum" + (filter ? "?filter=" + encodeURIComponent(filter) : ""));
      const json = await res.json();
      const rows = (json.data && json.data.rows) || [];
      const watch = new Set(loadWatch());
      const show = rows.slice(0, 40);
      if (!show.length) {
        box.innerHTML = "<div class='muted'>No rows for filter</div>";
        return;
      }
      box.innerHTML = show.map(function (r) {
        const br = r.btcRelative || {};
        const d7 = br.d7 && br.d7.available ? br.d7.excessReturnPp + "pp / " + br.d7.coinBtcReturnPct + "%" : "N/A";
        const d30 = br.d30 && br.d30.available ? br.d30.excessReturnPp + "pp" : "N/A";
        const d90 = br.d90 && br.d90.available ? br.d90.excessReturnPct || br.d90.excessReturnPp + "pp" : "N/A";
        return (
          "<div class='cmr-row'><span><strong>" + r.symbol + "</strong>" +
          (watch.has(String(r.symbol).toUpperCase()) ? " ★" : "") +
          (r.risk && r.risk.risky ? " <span class='warn'>Risky coin</span>" : "") +
          "<div class='muted'>7d excess " + d7 + " · 30d " + d30 + " · 90d " + d90 + "</div>" +
          (r.risk && r.risk.risky && r.risk.label
            ? "<div class='warn'>" + r.risk.label + "</div>"
            : "") +
          "</span></div>"
        );
      }).join("");
      const rot = json.data && json.data.rotation;
      if (rot) {
        box.innerHTML += "<div class='muted' style='margin-top:8px'>Rotation hypothesis: " + (rot.leadership || "—") +
          " · alts beating BTC 7d: " + (rot.altsBeatingBtc7d || 0) + " / " + (rot.eligibleSample || 0) +
          " <span class='warn'>(unvalidated)</span></div>";
      }
    } catch (_) {
      box.innerHTML = "<div class='warn'>BTC-relative unavailable</div>";
    }
  }

  async function loadTraction() {
    const box = ensureResearch().querySelector("#cmr-traction");
    box.innerHTML = "<div class='muted'>Loading setups then traction…</div>";
    try {
      const res = await origFetch(
        "/api/early-setups?limit=8&offset=0&candles=1&timeframe=1h&excludeHoldings=1&early=1&prioritizeHoldings=0&universe=0&symbols=" +
          watchlistQuery()
      );
      const json = await res.json();
      const candidates = ((json.data && json.data.setups) || []).filter(function (s) {
        return s.state === "Coiling" || s.state === "Igniting";
      }).slice(0, 3);
      if (!candidates.length) {
        box.innerHTML = "<div class='muted'>No Coiling/Igniting in the top universe slice — traction waits for those states.</div>";
        return;
      }
      const cards = [];
      for (let i = 0; i < candidates.length; i++) {
        const s = candidates[i];
        const qs = "/api/social?symbol=" + encodeURIComponent(s.symbol) +
          (s.name ? "&name=" + encodeURIComponent(s.name) : "") +
          (s.state ? "&state=" + encodeURIComponent(s.state) : "") +
          (s.setupReadiness != null ? "&readiness=" + encodeURIComponent(s.setupReadiness) : "");
        try {
          const sr = await origFetch(qs);
          const sj = await sr.json();
          const c = sj.data || {};
          cards.push(
            "<div class='cmr-row'><span><strong>" + s.symbol + "</strong> " + s.state +
            "<div class='" + (c.traction === "insufficient evidence" ? "muted" : "ok") + "'>traction: " + (c.traction || "—") + "</div>" +
            "<div class='muted'>risk: " + (c.entryRisk || "—") + "</div>" +
            ((c.conflicting && c.conflicting[0]) ? "<div class='warn'>" + c.conflicting[0] + "</div>" : "") +
            "</span></div>"
          );
        } catch (_) {
          cards.push("<div class='cmr-row'><span>" + s.symbol + "<div class='warn'>social unavailable</div></span></div>");
        }
      }
      box.innerHTML = cards.join("");
    } catch (_) {
      box.innerHTML = "<div class='warn'>Traction panel unavailable</div>";
    }
  }

  function patchMomentumPayload(payload) {
    if (!payload || !payload.data) return payload;
    const src = payload.data.sourceGeneratedAt || payload.data.freshness?.sourceGeneratedAt || payload.data.generatedAt;
    const freshness = compute(src, MAIN);
    payload.data.freshness = Object.assign({}, payload.data.freshness || {}, freshness);
    payload.data.sourceGeneratedAt = freshness.sourceGeneratedAt || payload.data.sourceGeneratedAt;
    if (payload.metadata) {
      payload.metadata.ageMinutes = freshness.ageMinutes;
      payload.metadata.fetchedAt = freshness.evaluatedAt;
      if (freshness.status !== "fresh") payload.metadata.status = freshness.status;
    }
    lastMain = payload;
    renderBanner();
    return payload;
  }

  function patchHfPayload(payload) {
    if (!payload || !payload.data) return payload;
    const src = payload.data.generatedAt || payload.data.freshness?.sourceGeneratedAt;
    const freshness = compute(src, HF);
    payload.data.freshness = Object.assign({}, payload.data.freshness || {}, freshness);
    lastHf = payload;
    renderBanner();
    return payload;
  }

  const origFetch = window.fetch.bind(window);
  window.fetch = async function (input, init) {
    const res = await origFetch(input, init);
    try {
      const url = typeof input === "string" ? input : input && input.url;
      if (!url || !res.ok) return res;
      if (url.includes("/api/momentum/cron")) return res;
      // Side-effect only: never rewrite Response bodies (avoids Content-Length
      // truncation that crashed the React app with undefined.toLowerCase).
      if (url.includes("/api/high-frequency")) {
        res.clone().json().then(function (data) { patchHfPayload(data); }).catch(function () {});
        return res;
      }
      if (url.includes("/api/momentum") && !url.includes("/api/momentum/")) {
        res.clone().json().then(function (data) { patchMomentumPayload(data); }).catch(function () {});
        return res;
      }
    } catch (_) {}
    return res;
  };

  function urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    const raw = atob(base64);
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  async function enablePhoneAlerts() {
    const btn = document.getElementById("cmr-enable-alerts");
    try {
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
        if (btn) btn.textContent = "Alerts need Chrome/Safari";
        return false;
      }
      const perm = await Notification.requestPermission();
      if (perm !== "granted") {
        if (btn) btn.textContent = "Allow notifications";
        return false;
      }
      const cfgRes = await origFetch("/api/push-subscribe");
      const cfg = await cfgRes.json();
      if (!cfg.configured || !cfg.publicKey) {
        if (btn) btn.textContent = "Push not configured yet";
        return false;
      }
      const reg = await navigator.serviceWorker.register("/sw.js");
      await navigator.serviceWorker.ready;
      let sub = await reg.pushManager.getSubscription();
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(cfg.publicKey),
        });
      }
      const save = await origFetch("/api/push-subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscription: sub.toJSON() }),
      });
      if (!save.ok) throw new Error("save_failed");
      if (btn) {
        btn.dataset.on = "true";
        btn.textContent = "Alerts ON";
      }
      return true;
    } catch (err) {
      if (btn) btn.textContent = "Alert setup failed — retry";
      return false;
    }
  }

  function ensureEnableAlerts() {
    ensureStyles();
    let btn = document.getElementById("cmr-enable-alerts");
    if (btn) return btn;
    btn = document.createElement("button");
    btn.id = "cmr-enable-alerts";
    btn.type = "button";
    btn.textContent = "Enable alerts";
    btn.addEventListener("click", function () { enablePhoneAlerts(); });
    document.body.appendChild(btn);
    origFetch("/api/push-subscribe").then(function (r) { return r.json(); }).then(function (cfg) {
      if (!cfg.configured) {
        btn.textContent = "Alerts coming online";
        return;
      }
      if (!("serviceWorker" in navigator)) return;
      navigator.serviceWorker.getRegistration("/sw.js").then(function (reg) {
        if (!reg) return;
        return reg.pushManager.getSubscription().then(function (sub) {
          if (sub) {
            btn.dataset.on = "true";
            btn.textContent = "Alerts ON";
          }
        });
      }).catch(function () {});
    }).catch(function () {});
    return btn;
  }

  function boot() {
    ensureBanner();
    ensureFomoAlertBanner();
    ensureEnableAlerts();
    ensureToggle();
    ensureResearch();
    renderWatch();
    renderBanner();
    syncTabs();
    // Always start collapsed so the homepage stays usable. User can reopen via the Research button.
    setResearchOpen(false);
    startFomoAlertPoll();
    if ("Notification" in window && Notification.permission === "default") {
      try { Notification.requestPermission(); } catch (_) {}
    }
    setInterval(function () {
      if (lastMain) patchMomentumPayload(lastMain);
      if (lastHf) patchHfPayload(lastHf);
      renderBanner();
    }, 15000);
    document.addEventListener("visibilitychange", function () {
      if (document.hidden || !researchOpen) return;
      panelsLoaded = false;
      loadActivePanel(true);
      pollFomoAlerts({ forcePass: true });
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
